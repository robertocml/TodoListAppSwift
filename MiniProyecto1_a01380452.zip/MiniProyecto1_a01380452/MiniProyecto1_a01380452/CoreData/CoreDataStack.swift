//
//  CoreDataStack.swift
//  MiniProyecto1_a01380452
//
//  Created by Roberto Perez on 2/19/18.
//  Copyright © 2018 Roberto Perez. All rights reserved.
//

import Foundation
import CoreData

class CoreDataStack {
    
    var container: NSPersistentContainer {
        let container = NSPersistentContainer(name: "Todos")
        container.loadPersistentStores { (description, error) in
            guard error == nil else {
                print("Error: \(error!)")
                return
                
            }
        }
        return container
    }
    
    
    
    var managedContext: NSManagedObjectContext {
        return container.viewContext
    }
}
