//
//  ViewController.swift
//  MiniProyecto1_a01380452
//
//  Created by Roberto Perez on 2/19/18.
//  Copyright © 2018 Roberto Perez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

